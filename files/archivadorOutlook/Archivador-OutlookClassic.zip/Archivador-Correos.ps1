<#
    Archivador-Correos.ps1
    -------------------------------------------------------------
    Interfaz grafica para archivar los correos de Outlook clasico
    en archivos PST locales, separados por anio (o anio/mes, o un
    unico archivo), y asi liberar espacio en el servidor (O365).

    Ver INSTRUCTIVO.txt para el detalle completo de uso y advertencias.

    OJO CON EL CACHE: si la cuenta esta en Cached Exchange Mode con
    el slider en un periodo limitado (ej. 12 meses), el correo mas
    viejo no esta bajado localmente y el programa NO lo va a ver.
    Antes de archivar correo viejo, pone el slider en "Todo".
#>

Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing

# ----- Constantes Outlook -----
$olStoreUnicode = 3    # PST Unicode (soporta buzones grandes)
$olMail         = 43   # solo items de tipo correo

# ----- Colores de la consola -----
$colInfo = [System.Drawing.Color]::Gainsboro
$colOk   = [System.Drawing.Color]::LightGreen
$colWarn = [System.Drawing.Color]::Khaki
$colErr  = [System.Drawing.Color]::Salmon
$colHead = [System.Drawing.Color]::LightSkyBlue

# ----- Estado -----
$script:Detener      = $false
$script:ResumenTexto = ""
$script:suppressCheck = $false
$script:outlook      = $null
$script:ns           = $null

# ================= FUNCIONES ================================

function Connect-Outlook {
    if ($null -eq $script:outlook) {
        $script:outlook = New-Object -ComObject Outlook.Application
        $script:ns      = $script:outlook.GetNamespace("MAPI")
    }
    return $script:ns
}

function Write-Console {
    param([string]$texto, $color)
    if ($null -eq $color) { $color = $colInfo }
    $console.SelectionStart = $console.TextLength
    $console.SelectionColor = $color
    $console.AppendText($texto + "`r`n")
    $console.SelectionColor = $colInfo
    $console.ScrollToCaret()
    [System.Windows.Forms.Application]::DoEvents()
}

function Ensure-Subfolder {
    param($parent, [string]$name)
    foreach ($f in $parent.Folders) { if ($f.Name -eq $name) { return $f } }
    return $parent.Folders.Add($name)
}

# ---- Arbol de carpetas ----
function Agregar-Nodos {
    param($carpeta, $nodo)
    foreach ($sub in $carpeta.Folders) {
        $n = $nodo.Nodes.Add($sub.Name)
        $n.Tag = $sub
        Agregar-Nodos $sub $n
    }
}

function Cargar-Arbol {
    try {
        Write-Console "Conectando con Outlook y leyendo carpetas..." $colInfo
        $ns = Connect-Outlook
        $tree.Nodes.Clear()
        foreach ($store in $ns.Stores) {
            try {
                $raiz = $store.GetRootFolder()
                $nodo = $tree.Nodes.Add($raiz.Name)
                $nodo.Tag = $raiz
                Agregar-Nodos $raiz $nodo
                $nodo.Expand()
            } catch {
                Write-Console "  no pude leer un store: $($_.Exception.Message)" $colWarn
            }
        }
        Write-Console "Carpetas cargadas. Marca las que quieras archivar." $colOk
    } catch {
        Write-Console "ERROR cargando carpetas: $($_.Exception.Message)" $colErr
        Write-Console "Abri Outlook, espera que sincronice y toca 'Cargar carpetas' de nuevo." $colWarn
    }
}

function Set-ChildrenChecked {
    param($nodo, [bool]$estado)
    foreach ($c in $nodo.Nodes) {
        $c.Checked = $estado
        Set-ChildrenChecked $c $estado
    }
}

function Recolectar-Marcadas {
    param($nodo, [System.Collections.ArrayList]$acc)
    # Level 0 = raiz del store (no tiene correos utiles); se saltea pero se recorre.
    if ($nodo.Checked -and $nodo.Level -ge 1 -and $null -ne $nodo.Tag) {
        [void]$acc.Add($nodo.Tag)
    }
    foreach ($c in $nodo.Nodes) { Recolectar-Marcadas $c $acc }
}

# ---- Destino PST ----
function Get-CarpetaDestino {
    param([int]$anio, [int]$mes, [string]$nombreOrigen, [string]$modo, [string]$rutaBase)

    if ($modo -eq 'unico') {
        $pstPath    = Join-Path $rutaBase "Archivo.pst"
        $claveStore = "unico"
    } else {
        $pstPath    = Join-Path $rutaBase ("Archivo_{0}.pst" -f $anio)
        $claveStore = "$anio"
    }

    if (-not $script:StoreCache.ContainsKey($claveStore)) {
        $script:ns.AddStoreEx($pstPath, $olStoreUnicode)
        $store = $null
        foreach ($s in $script:ns.Stores) { if ($s.FilePath -eq $pstPath) { $store = $s; break } }
        $script:StoreCache[$claveStore] = $store
    }
    $raiz = $script:StoreCache[$claveStore].GetRootFolder()

    $dest = Ensure-Subfolder -parent $raiz -name $nombreOrigen
    if ($modo -eq 'aniomes') {
        $dest = Ensure-Subfolder -parent $dest -name ("{0:0000}-{1:00}" -f $anio, $mes)
    }
    return $dest
}

function Ejecutar {
    param([bool]$Simular)

    $script:Detener     = $false
    $btnSimular.Enabled = $false
    $btnRun.Enabled     = $false
    $btnDetener.Enabled = $true
    try {
        $rutaBase = $txtPath.Text.Trim()
        if ([string]::IsNullOrWhiteSpace($rutaBase)) {
            Write-Console "Falta indicar la carpeta destino." $colErr; return
        }
        if (-not (Test-Path $rutaBase)) {
            New-Item -ItemType Directory -Path $rutaBase -Force | Out-Null
            Write-Console "Carpeta creada: $rutaBase" $colOk
        }

        $modo  = if ($rbYear.Checked) { 'anio' } elseif ($rbYearMonth.Checked) { 'aniomes' } else { 'unico' }
        $hasta = [int]$numHasta.Value

        Connect-Outlook | Out-Null

        # Carpetas marcadas en el arbol
        $carpetas = New-Object System.Collections.ArrayList
        foreach ($top in $tree.Nodes) { Recolectar-Marcadas $top $carpetas }
        if ($carpetas.Count -eq 0) {
            Write-Console "No marcaste ninguna carpeta. Toca 'Cargar carpetas' y marca al menos una." $colErr
            return
        }

        $etqFiltro = if ($hasta -gt 0) { "solo hasta $hasta" } else { "todos los anios" }
        Write-Console ("Carpetas: {0} | Modo: {1} | Filtro: {2} | Simulacion: {3}" -f `
            $carpetas.Count, $modo, $etqFiltro, $Simular) $colInfo

        $script:StoreCache = @{}
        $granTotal    = 0
        $resumenAnios = @{}
        $cortado      = $false

        foreach ($carpeta in $carpetas) {
            if ($script:Detener) { $cortado = $true; break }
            Write-Console "`n=== $($carpeta.FolderPath) ===" $colHead
            $items = $carpeta.Items
            $cnt   = $items.Count
            $proc  = 0

            # De atras hacia adelante: al mover, la coleccion se achica.
            for ($i = $cnt; $i -ge 1; $i--) {
                if ($script:Detener) { $cortado = $true; break }
                try {
                    $item = $items.Item($i)
                    if ($item.Class -ne $olMail) { continue }

                    $fecha = $null
                    try { $fecha = $item.ReceivedTime } catch {}
                    if ($null -eq $fecha) { try { $fecha = $item.SentOn } catch {} }
                    if ($null -eq $fecha) { continue }

                    $anio = $fecha.Year
                    if ($hasta -gt 0 -and $anio -gt $hasta) { continue }

                    if (-not $resumenAnios.ContainsKey($anio)) { $resumenAnios[$anio] = 0 }
                    $resumenAnios[$anio]++
                    $granTotal++
                    $proc++

                    if (-not $Simular) {
                        $destino = Get-CarpetaDestino -anio $anio -mes $fecha.Month `
                                    -nombreOrigen $carpeta.Name -modo $modo -rutaBase $rutaBase
                        $item.Move($destino) | Out-Null
                    }
                }
                catch {
                    Write-Console "  item omitido: $($_.Exception.Message)" $colWarn
                }
                if (($i % 25) -eq 0) { [System.Windows.Forms.Application]::DoEvents() }
            }

            $verbo = if ($Simular) { "(simulado)" } else { "movidos" }
            Write-Console ("  {0} correos {1}" -f $proc, $verbo) $colInfo
        }

        if ($cortado) { Write-Console "`n*** DETENIDO por el usuario. Lo procesado ya quedo aplicado. ***" $colWarn }

        # ----- Resumen (para consola y para exportar) -----
        $sb = New-Object System.Text.StringBuilder
        [void]$sb.AppendLine("RESUMEN DE ARCHIVADO DE CORREOS - Petromark")
        [void]$sb.AppendLine("Fecha:        " + (Get-Date -Format "yyyy-MM-dd HH:mm:ss"))
        [void]$sb.AppendLine("Operacion:    " + $(if ($Simular) { "SIMULACION (no se movio nada)" } else { "ARCHIVADO REAL" }))
        [void]$sb.AppendLine("Modo:         " + $modo)
        [void]$sb.AppendLine("Filtro anio:  " + $etqFiltro)
        [void]$sb.AppendLine("Destino PST:  " + $rutaBase)
        [void]$sb.AppendLine("Carpetas:     " + $carpetas.Count)
        [void]$sb.AppendLine("Detenido:     " + $(if ($cortado) { "SI" } else { "no" }))
        [void]$sb.AppendLine("")
        [void]$sb.AppendLine("Conteo por anio:")
        foreach ($a in ($resumenAnios.Keys | Sort-Object)) {
            [void]$sb.AppendLine(("  {0}: {1} correos" -f $a, $resumenAnios[$a]))
        }
        [void]$sb.AppendLine("")
        [void]$sb.AppendLine(("TOTAL: {0} correos" -f $granTotal))
        $script:ResumenTexto = $sb.ToString()

        Write-Console "`n----- RESUMEN POR ANIO -----" $colHead
        foreach ($a in ($resumenAnios.Keys | Sort-Object)) {
            Write-Console ("  {0}: {1} correos" -f $a, $resumenAnios[$a]) $colInfo
        }
        Write-Console ("  TOTAL: {0} correos" -f $granTotal) $colInfo

        if ($Simular) {
            Write-Console "`nMODO SIMULACION: no se movio nada. Si el resumen esta bien, usa 'Archivar y liberar espacio'." $colWarn
        } elseif (-not $cortado) {
            Write-Console "`nLISTO. Los correos quedaron en $rutaBase y se libero espacio en el servidor." $colOk
        }
        Write-Console "Podes guardar este resumen con 'Exportar resumen (TXT)'." $colInfo
    }
    catch {
        Write-Console "ERROR: $($_.Exception.Message)" $colErr
    }
    finally {
        $script:Detener     = $false
        $btnSimular.Enabled = $true
        $btnRun.Enabled     = $true
        $btnDetener.Enabled = $false
    }
}

# ===================== INTERFAZ ==============================

$form = New-Object System.Windows.Forms.Form
$form.Text = "Archivador de correos - Petromark"
$form.Size = New-Object System.Drawing.Size(650, 775)
$form.StartPosition = "CenterScreen"
$form.FormBorderStyle = "FixedSingle"
$form.MaximizeBox = $false

# --- GroupBox Carpetas (arbol) ---
$gbCarpetas = New-Object System.Windows.Forms.GroupBox
$gbCarpetas.Text = "Carpetas del buzon"
$gbCarpetas.Location = New-Object System.Drawing.Point(15, 12)
$gbCarpetas.Size = New-Object System.Drawing.Size(610, 210)
$form.Controls.Add($gbCarpetas)

$lblCarpetas = New-Object System.Windows.Forms.Label
$lblCarpetas.Text = "Marca las carpetas a archivar (al marcar una, se marcan sus subcarpetas):"
$lblCarpetas.Location = New-Object System.Drawing.Point(15, 22)
$lblCarpetas.AutoSize = $true
$gbCarpetas.Controls.Add($lblCarpetas)

$btnCargar = New-Object System.Windows.Forms.Button
$btnCargar.Text = "Cargar carpetas"
$btnCargar.Location = New-Object System.Drawing.Point(455, 18)
$btnCargar.Size = New-Object System.Drawing.Size(140, 26)
$gbCarpetas.Controls.Add($btnCargar)

$tree = New-Object System.Windows.Forms.TreeView
$tree.CheckBoxes = $true
$tree.Location = New-Object System.Drawing.Point(15, 52)
$tree.Size = New-Object System.Drawing.Size(580, 148)
$gbCarpetas.Controls.Add($tree)

# --- GroupBox Modo ---
$gbModo = New-Object System.Windows.Forms.GroupBox
$gbModo.Text = "Modo de guardado"
$gbModo.Location = New-Object System.Drawing.Point(15, 230)
$gbModo.Size = New-Object System.Drawing.Size(300, 115)
$form.Controls.Add($gbModo)

$rbYear = New-Object System.Windows.Forms.RadioButton
$rbYear.Text = "Un PST por anio (Archivo_2023.pst)"
$rbYear.Checked = $true
$rbYear.Location = New-Object System.Drawing.Point(15, 25)
$rbYear.AutoSize = $true
$gbModo.Controls.Add($rbYear)

$rbYearMonth = New-Object System.Windows.Forms.RadioButton
$rbYearMonth.Text = "Por anio, subcarpetas por mes"
$rbYearMonth.Location = New-Object System.Drawing.Point(15, 50)
$rbYearMonth.AutoSize = $true
$gbModo.Controls.Add($rbYearMonth)

$rbSingle = New-Object System.Windows.Forms.RadioButton
$rbSingle.Text = "Un unico PST de archivo"
$rbSingle.Location = New-Object System.Drawing.Point(15, 75)
$rbSingle.AutoSize = $true
$gbModo.Controls.Add($rbSingle)

# --- GroupBox Filtro ---
$gbFiltro = New-Object System.Windows.Forms.GroupBox
$gbFiltro.Text = "Filtro por anio"
$gbFiltro.Location = New-Object System.Drawing.Point(325, 230)
$gbFiltro.Size = New-Object System.Drawing.Size(300, 115)
$form.Controls.Add($gbFiltro)

$lblHasta = New-Object System.Windows.Forms.Label
$lblHasta.Text = "Archivar solo correos hasta el anio (incluido).  0 = todos los anios:"
$lblHasta.Location = New-Object System.Drawing.Point(15, 25)
$lblHasta.Size = New-Object System.Drawing.Size(270, 35)
$gbFiltro.Controls.Add($lblHasta)

$numHasta = New-Object System.Windows.Forms.NumericUpDown
$numHasta.Minimum = 0
$numHasta.Maximum = 2100
$numHasta.Value = 0
$numHasta.Location = New-Object System.Drawing.Point(15, 70)
$numHasta.Size = New-Object System.Drawing.Size(90, 22)
$gbFiltro.Controls.Add($numHasta)

# --- GroupBox Destino ---
$gbDestino = New-Object System.Windows.Forms.GroupBox
$gbDestino.Text = "Carpeta destino de los PST"
$gbDestino.Location = New-Object System.Drawing.Point(15, 352)
$gbDestino.Size = New-Object System.Drawing.Size(610, 65)
$form.Controls.Add($gbDestino)

$txtPath = New-Object System.Windows.Forms.TextBox
$txtPath.Text = "C:\ArchivosCorreo"
$txtPath.Location = New-Object System.Drawing.Point(15, 27)
$txtPath.Size = New-Object System.Drawing.Size(490, 22)
$gbDestino.Controls.Add($txtPath)

$btnBrowse = New-Object System.Windows.Forms.Button
$btnBrowse.Text = "..."
$btnBrowse.Location = New-Object System.Drawing.Point(515, 25)
$btnBrowse.Size = New-Object System.Drawing.Size(80, 25)
$gbDestino.Controls.Add($btnBrowse)

# --- Consola ---
$console = New-Object System.Windows.Forms.RichTextBox
$console.Location = New-Object System.Drawing.Point(15, 425)
$console.Size = New-Object System.Drawing.Size(610, 205)
$console.ReadOnly = $true
$console.BackColor = [System.Drawing.Color]::FromArgb(20, 20, 20)
$console.ForeColor = $colInfo
$console.Font = New-Object System.Drawing.Font("Consolas", 9)
$form.Controls.Add($console)

# --- Botones (fila 1) ---
$btnSimular = New-Object System.Windows.Forms.Button
$btnSimular.Text = "Simular (no mueve nada)"
$btnSimular.Location = New-Object System.Drawing.Point(15, 640)
$btnSimular.Size = New-Object System.Drawing.Size(195, 34)
$form.Controls.Add($btnSimular)

$btnDetener = New-Object System.Windows.Forms.Button
$btnDetener.Text = "Detener"
$btnDetener.Enabled = $false
$btnDetener.Location = New-Object System.Drawing.Point(220, 640)
$btnDetener.Size = New-Object System.Drawing.Size(195, 34)
$form.Controls.Add($btnDetener)

$btnRun = New-Object System.Windows.Forms.Button
$btnRun.Text = "Archivar y liberar espacio"
$btnRun.Location = New-Object System.Drawing.Point(425, 640)
$btnRun.Size = New-Object System.Drawing.Size(195, 34)
$btnRun.BackColor = [System.Drawing.Color]::FromArgb(198, 40, 40)
$btnRun.ForeColor = [System.Drawing.Color]::White
$form.Controls.Add($btnRun)

# --- Botones (fila 2) ---
$btnExport = New-Object System.Windows.Forms.Button
$btnExport.Text = "Exportar resumen (TXT)"
$btnExport.Location = New-Object System.Drawing.Point(15, 682)
$btnExport.Size = New-Object System.Drawing.Size(195, 34)
$form.Controls.Add($btnExport)

$btnClear = New-Object System.Windows.Forms.Button
$btnClear.Text = "Limpiar consola"
$btnClear.Location = New-Object System.Drawing.Point(220, 682)
$btnClear.Size = New-Object System.Drawing.Size(195, 34)
$form.Controls.Add($btnClear)

# --- Eventos ---
$tree.Add_AfterCheck({
    param($s, $e)
    if ($script:suppressCheck) { return }
    $script:suppressCheck = $true
    Set-ChildrenChecked $e.Node $e.Node.Checked
    $script:suppressCheck = $false
})

$btnCargar.Add_Click({ Cargar-Arbol })

$btnBrowse.Add_Click({
    $dlg = New-Object System.Windows.Forms.FolderBrowserDialog
    if ($dlg.ShowDialog() -eq [System.Windows.Forms.DialogResult]::OK) {
        $txtPath.Text = $dlg.SelectedPath
    }
})

$btnSimular.Add_Click({ Ejecutar -Simular:$true })

$btnRun.Add_Click({
    $r = [System.Windows.Forms.MessageBox]::Show(
        "Esto va a MOVER los correos a los PST locales y sacarlos del servidor.`n`nAsegurate de haber simulado primero.  Continuar?",
        "Confirmar archivado", [System.Windows.Forms.MessageBoxButtons]::YesNo,
        [System.Windows.Forms.MessageBoxIcon]::Warning)
    if ($r -eq [System.Windows.Forms.DialogResult]::Yes) { Ejecutar -Simular:$false }
})

$btnDetener.Add_Click({
    $script:Detener = $true
    Write-Console "Deteniendo... (frena al terminar el correo actual)" $colWarn
})

$btnExport.Add_Click({
    if ([string]::IsNullOrWhiteSpace($script:ResumenTexto)) {
        [System.Windows.Forms.MessageBox]::Show(
            "Primero corre una simulacion o un archivado.", "Sin datos",
            [System.Windows.Forms.MessageBoxButtons]::OK,
            [System.Windows.Forms.MessageBoxIcon]::Information) | Out-Null
        return
    }
    $dlg = New-Object System.Windows.Forms.SaveFileDialog
    $dlg.Filter = "Texto (*.txt)|*.txt"
    $dlg.FileName = "Resumen_Archivado_" + (Get-Date -Format "yyyyMMdd_HHmmss") + ".txt"
    if (-not [string]::IsNullOrWhiteSpace($txtPath.Text) -and (Test-Path $txtPath.Text)) {
        $dlg.InitialDirectory = $txtPath.Text
    }
    if ($dlg.ShowDialog() -eq [System.Windows.Forms.DialogResult]::OK) {
        Set-Content -Path $dlg.FileName -Value $script:ResumenTexto -Encoding UTF8
        Write-Console "Resumen exportado a: $($dlg.FileName)" $colOk
    }
})

$btnClear.Add_Click({ $console.Clear() })

# --- Arranque ---
Write-Console "Bienvenido. Paso 1: toca 'Cargar carpetas' para ver el arbol del buzon." $colOk
Write-Console "OJO: si el modo cache tiene el slider limitado, ponelo en 'Todo' antes de archivar (ver INSTRUCTIVO.txt)." $colWarn

# Intento de carga automatica (si Outlook esta abierto)
Cargar-Arbol

[void]$form.ShowDialog()
