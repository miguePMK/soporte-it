@echo off
REM Lanza la GUI de PowerShell en modo STA (necesario para WinForms)
REM y con la politica de ejecucion desbloqueada solo para este proceso.
powershell.exe -NoProfile -ExecutionPolicy Bypass -STA -File "%~dp0Archivador-Correos.ps1"
