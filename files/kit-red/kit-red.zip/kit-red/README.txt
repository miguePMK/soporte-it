Kit de diagnostico de red (DEMO)
Archivo de ejemplo. Reemplazar por el paquete real.
